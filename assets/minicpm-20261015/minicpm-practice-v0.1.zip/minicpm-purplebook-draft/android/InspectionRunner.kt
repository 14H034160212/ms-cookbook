package com.example.minicpm_v_demo

import android.util.JsonReader
import android.util.JsonToken
import java.io.StringReader
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

data class InspectionDraft(
    val objectName: String?,
    val visibleIssue: String?,
    val needsRetake: Boolean,
    val missingFields: List<String>
)

object InspectionContract {
    const val PROMPT = "根据照片生成现场巡检观察草稿。只输出JSON对象，只有object、visible_issue、needs_retake、missing_fields四个字段。object和visible_issue为字符串或null，仅写图中可见的对象与现象，不判断故障原因或维修方法。needs_retake为布尔值；暗光、模糊或无法判断时为true，无法确认的字段填null。missing_fields只能包含object和visible_issue中为null的字段名。位置、拍摄时间、处理状态由应用记录，不要生成。不要解释、Markdown或思考内容。"

    fun parse(raw: String): InspectionDraft {
        JsonReader(StringReader(raw)).use { reader ->
            reader.isLenient = false
            reader.beginObject()
            val seen = mutableSetOf<String>()
            var objectName: String? = null
            var issue: String? = null
            var retake = false
            val missing = mutableListOf<String>()
            fun nullableString(): String? {
                if (reader.peek() == JsonToken.NULL) { reader.nextNull(); return null }
                require(reader.peek() == JsonToken.STRING) { "Expected string or null" }
                return reader.nextString().also { require(it.isNotBlank() && it.length <= 300) }
            }
            while (reader.hasNext()) {
                val key = reader.nextName()
                require(seen.add(key)) { "Duplicate field" }
                when (key) {
                    "object" -> objectName = nullableString()
                    "visible_issue" -> issue = nullableString()
                    "needs_retake" -> { require(reader.peek() == JsonToken.BOOLEAN); retake = reader.nextBoolean() }
                    "missing_fields" -> {
                        reader.beginArray()
                        while (reader.hasNext()) {
                            require(reader.peek() == JsonToken.STRING)
                            missing.add(reader.nextString())
                        }
                        reader.endArray()
                    }
                    else -> error("Unexpected field")
                }
            }
            reader.endObject()
            require(reader.peek() == JsonToken.END_DOCUMENT) { "Trailing content" }
            require(seen == setOf("object", "visible_issue", "needs_retake", "missing_fields"))
            val expectedMissing = mutableSetOf<String>()
            if (objectName == null) expectedMissing.add("object")
            if (issue == null) expectedMissing.add("visible_issue")
            require(missing.toSet() == expectedMissing && missing.distinct().size == missing.size)
            return InspectionDraft(objectName, issue, retake, missing)
        }
    }
}

/** Use one shared runner; engine has already loaded the V4.6 LLM and matching mmproj. */
class InspectionRunner(private val engine: LlamaEngine) {
    private val mutex = Mutex()
    suspend fun generate(jpegBytes: ByteArray): InspectionDraft = mutex.withLock {
        require(engine.isVisionSupported) { "Matching vision component must be loaded" }
        engine.setEnableThinking(false)
        // Never carry observations from the previous location into this inspection.
        engine.clearContext()
        engine.setSystemPrompt(InspectionContract.PROMPT)
        engine.prefillImage(jpegBytes)
        val result = StringBuilder()
        engine.sendUserPrompt("请提取图中可见的对象和现象。", predictLength = 384).collect {
            result.append(it)
        }
        InspectionContract.parse(result.toString())
    }
}
