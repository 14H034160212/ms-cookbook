package com.example.minicpm_v_demo

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

/** App-private durable outbox. Call syncPending only after the user taps Sync. */
class InspectionRecordStore(context: Context) : SQLiteOpenHelper(context, "inspection.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE outbox(record_id TEXT PRIMARY KEY, payload TEXT NOT NULL, synced INTEGER NOT NULL DEFAULT 0, remote_status TEXT, remote_version INTEGER)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        error("Define an explicit migration before changing schema version")
    }

    @Synchronized
    fun saveConfirmed(record: JSONObject) {
        val fields = setOf("record_id", "captured_at", "location", "object", "visible_issue", "image_sha256", "model_id", "model_revision", "confirmed_by", "confirmed_at", "human_confirmed")
        require(record.keys().asSequence().toSet() == fields)
        require(record.opt("human_confirmed") == true)
        UUID.fromString(record.getString("record_id"))
        for (field in fields - "human_confirmed") {
            require(record.opt(field) is String && record.getString(field).isNotBlank())
        }
        require(record.getString("image_sha256").matches(Regex("[0-9a-f]{64}")))
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.rawQuery("SELECT payload FROM outbox WHERE record_id=?", arrayOf(record.getString("record_id"))).use { cursor ->
                if (cursor.moveToFirst()) {
                    require(sameRecord(JSONObject(cursor.getString(0)), record)) { "Confirmed records are immutable" }
                } else {
                    db.execSQL("INSERT INTO outbox(record_id,payload) VALUES(?,?)", arrayOf(record.getString("record_id"), record.toString()))
                }
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    private fun sameRecord(a: JSONObject, b: JSONObject): Boolean =
        a.keys().asSequence().toSet() == b.keys().asSequence().toSet() &&
        a.keys().asSequence().all { a.get(it) == b.get(it) }

    fun pending(): List<JSONObject> {
        val result = mutableListOf<JSONObject>()
        readableDatabase.rawQuery("SELECT payload FROM outbox WHERE synced=0 ORDER BY record_id", null).use { c ->
            while (c.moveToNext()) result.add(JSONObject(c.getString(0)))
        }
        return result
    }

    /** Run off the UI thread; a failed or conflicting POST stays in the queue. */
    fun syncPending(baseUrl: String, bearerToken: String? = null): List<Pair<String, Boolean>> =
        pending().map { record ->
            val id = record.getString("record_id")
            val bytes = record.toString().toByteArray(Charsets.UTF_8)
            val connection = URL(baseUrl.trimEnd('/') + "/records").openConnection() as HttpURLConnection
            try {
                connection.requestMethod = "POST"
                connection.connectTimeout = 10000
                connection.readTimeout = 10000
                connection.doOutput = true
                connection.setRequestProperty("Content-Type", "application/json")
                if (bearerToken != null) connection.setRequestProperty("Authorization", "Bearer $bearerToken")
                connection.setFixedLengthStreamingMode(bytes.size)
                connection.outputStream.use { it.write(bytes) }
                require(connection.responseCode == 200 || connection.responseCode == 201)
                val ack = connection.inputStream.bufferedReader().use { JSONObject(it.readText()) }
                require(sameRecord(ack.getJSONObject("record"), record)) { "Mismatched server acknowledgment" }
                writableDatabase.execSQL("UPDATE outbox SET synced=1,remote_status=?,remote_version=? WHERE record_id=?",
                    arrayOf(ack.getString("status"), ack.getInt("version"), id))
                id to true
            } catch (e: Exception) { id to false }
            finally { connection.disconnect() }
        }

    /** Explicit refresh for a synced record; never overwrites local observation fields. */
    fun refreshStatus(baseUrl: String, recordId: String, bearerToken: String? = null): JSONObject {
        UUID.fromString(recordId)
        val connection = URL(baseUrl.trimEnd('/') + "/records/" + recordId).openConnection() as HttpURLConnection
        try {
            connection.connectTimeout = 10000
            connection.readTimeout = 10000
            if (bearerToken != null) connection.setRequestProperty("Authorization", "Bearer $bearerToken")
            require(connection.responseCode == 200)
            val remote = connection.inputStream.bufferedReader().use { JSONObject(it.readText()) }
            require(remote.getJSONObject("record").getString("record_id") == recordId)
            writableDatabase.execSQL("UPDATE outbox SET remote_status=?,remote_version=? WHERE record_id=?",
                arrayOf(remote.getString("status"), remote.getInt("version"), recordId))
            return remote
        } finally { connection.disconnect() }
    }
}
