"""Contract for model drafts and confirmed business records."""
import hashlib
import json
import uuid
from task_contract import loads_strict

VISION_PROMPT = ('根据照片生成现场巡检观察草稿。只输出JSON对象，只有object、visible_issue、'
                 'needs_retake、missing_fields四个字段。object和visible_issue为字符串或null，'
                 '仅写图中可见的对象与现象，不判断故障原因或维修方法。'
                 'needs_retake为布尔值；暗光、模糊或无法判断时为true，无法确认的字段填null。'
                 'missing_fields只能包含object和visible_issue中为null的字段名。'
                 '位置、拍摄时间、处理状态由应用记录，不要生成。不要解释、Markdown或思考内容。')

def parse_draft(text):
    v = loads_strict(text)
    if not isinstance(v,dict) or set(v) != {'object','visible_issue','needs_retake','missing_fields'}:
        raise ValueError('invalid draft fields')
    for key in ('object','visible_issue'):
        if v[key] is not None and (not isinstance(v[key],str) or not v[key].strip() or len(v[key])>300):
            raise ValueError('invalid observation')
    if type(v['needs_retake']) is not bool or not isinstance(v['missing_fields'],list):
        raise ValueError('invalid retake / missing fields')
    if set(v['missing_fields']) != {key for key in ('object','visible_issue') if v[key] is None}:
        raise ValueError('missing fields must match null fields')
    if len(set(v['missing_fields'])) != len(v['missing_fields']):
        raise ValueError('duplicate missing field')
    return v

def validate_record(v):
    fields = {'record_id','captured_at','location','object','visible_issue','image_sha256',
              'model_id','model_revision','confirmed_by','confirmed_at','human_confirmed'}
    if not isinstance(v,dict) or set(v)!=fields:
        raise ValueError('invalid record fields')
    uuid.UUID(v['record_id'])
    for key in fields - {'record_id','human_confirmed'}:
        if not isinstance(v[key],str) or not v[key].strip() or len(v[key])>500:
            raise ValueError('missing or invalid '+key)
    if v['human_confirmed'] is not True:
        raise ValueError('human confirmation required')
    from datetime import datetime
    for key in ('captured_at','confirmed_at'):
        stamp=datetime.fromisoformat(v[key].replace('Z','+00:00'))
        if stamp.tzinfo is None:
            raise ValueError('timezone required')
    if len(v['image_sha256'])!=64 or any(c not in '0123456789abcdef' for c in v['image_sha256']):
        raise ValueError('invalid image SHA256')
    return v

def digest(v):
    return hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
