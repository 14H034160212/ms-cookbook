# 用 MiniCPM-V 搭建手机巡检助手：拍照生成现场记录

物业巡检人员走到二层东侧走廊，看到灯罩破损，拍下一张照片。在现场生成观察草稿，核对对象和现象，补充位置后保存；没有网络时继续巡查，有网络时再把确认过的记录同步到台账。这是本章要完成的工作流程。

手机在这里承担现场采集、模型运行、人工确认和离线保存。MiniCPM-V 根据图片提取可见信息，应用负责时间、位置和记录状态，台账承接后续处理。模型生成的是观察草稿，工作人员决定哪些内容可以成为正式记录。

![手机本地巡检记录的确认和显式同步流程](../figures/inspection-workflow.svg)

> 本稿以合作方案中的物业巡检示例展开，尚不是已有落地案例的复盘。使用有公开手机工程的 MiniCPM-V 4.6 作为初稿基线；配套提供 Notebook 基线脚本、Android 集成组件和可运行的模拟台账。完整手机界面、真实图片标注与实机报告需在定稿前补齐。

## 1. 把巡检需求变成明确的模型任务

首个版本只处理公共区域中可以拍到的表面现象，例如灯罩破损、地面散落物和墙面可见污迹。它不从照片确定电路是否损坏，也不决定是否需要停机、维修或更换设备。

假设照片中可见破损灯罩，用户输入位置“二层东侧走廊”，模型草稿的目标结构是：

```json
{
  "object": "灯罩",
  "visible_issue": "灯罩表面可见破损",
  "needs_retake": false,
  "missing_fields": []
}
```

这是期望输出示例，不是模型实测回答。若图片暗到无法确认，契约允许返回：

```json
{
  "object": null,
  "visible_issue": null,
  "needs_retake": true,
  "missing_fields": ["object", "visible_issue"]
}
```

`needs_retake` 只是一条模型建议，没有校准概率的含义。即使它为 false，也仍然需要人员查看照片与字段。清晰的正常场景可以描述“未见明显表面异常”，这表示照片范围内的观察，不等于设备整体正常。

### 字段来自哪里

| 字段 | 产生者 | 约束 |
| --- | --- | --- |
| 对象 object、可见现象 visible_issue | 模型提出、人员修改确认 | 只写有图像依据的信息；无法确认时留空 |
| 是否建议重拍、缺失字段 | 模型与应用校验 | 提醒用户补拍或补录；不作为诊断结论 |
| 拍摄时间 captured_at | 应用 | 保存带时区的时间；说明是否来自现场相机或相册导入 |
| 位置 location | 用户选择或输入 | 第一版不用模型猜测楼层，不把未经授权定位当成默认输入 |
| 记录 ID | 应用 | 创建后固定，重试同步仍使用同一 ID |
| 图片 SHA256、模型版本 | 应用 | 用于关联原始输入与推理产物 |
| 确认人、确认时间 | 人员操作与应用 | 只有点击确认后生成正式记录 |
| 处理状态、服务端版本 | 台账 | 待处理、处理中、已关闭，独立于模型草稿 |

位置先由用户输入，不把它交给模型生成，能避免照片里没有楼层信息却产生一个貌似完整的位置。拍摄时间也应来自业务应用，不依赖模型对“现在”的判断。

## 2. 先在 Notebook 中验证单图理解

模型入口为 [魔搭 MiniCPM-V 4.6](https://modelscope.cn/models/OpenBMB/MiniCPM-V-4.6)。它支持图像、视频与文本输入。本章只使用单张图片，不同时引入语音、视频流和工具调用。

在魔搭 Notebook 中打开配套 `notebooks/02_minicpmv_inspection_baseline.ipynb`，下载固定模型版本，上传一张自己拥有使用权限的图片。模型代码采用官方的 Transformers 路线：

```bash
python -m pip install 'transformers==5.7.0' 'modelscope==1.33.0' \
  accelerate Pillow torchvision av
```

保留与 Notebook CUDA 相匹配的 PyTorch / torchvision 组合，避免为了一个单图实验升级整个 CUDA 软件栈。本章初稿未记录 GPU 峰值显存，应在正式验证中填写。官方仓库根目录的旧 requirements 包含早期模型依赖，不应直接替代 4.6 对应的推理说明。

运行下载单元格后，使用配套脚本：

```bash
python examples/vision_baseline.py \
  --model models/minicpm-v-4.6 \
  --image 自己的现场照片.jpg \
  --downsample 16x \
  --out results/inspection-one.json
```

脚本的核心调用如下：

```python
inputs = processor.apply_chat_template(
    messages, tokenize=True, add_generation_prompt=True,
    enable_thinking=False, return_dict=True, return_tensors="pt",
    downsample_mode="16x", max_slice_nums=1
).to(model.device)

generated_ids = model.generate(
    **inputs, downsample_mode="16x",
    do_sample=False, max_new_tokens=384
)
```

使用与当前模型匹配的 `AutoProcessor`、`AutoModelForImageTextToText` 和系统提示。`downsample_mode` 必须在预处理和生成两处保持一致，否则图像占位与视觉特征可能不匹配。

16x 与 4x 是精度和计算开销的取舍，不能用一般性的“更快”承诺替代具体巡检图片测试。初始设置 `max_slice_nums=1` 是为了限制资源；细小文字、远处裂痕或大场景可能需要增加切片、改用 4x 或重新近距离拍摄。手机工程使用自己的视觉处理接口，不应把 Notebook 的参数名直接假定为手机中同名设置。

脚本同时保存原始回答和结构校验结果。合法 JSON 只证明结构满足要求，是否看对图片需要人工标注与核对。如果原始输出不合法，保留错误，允许重新生成或手工填写，不将非法输出“修一下”后计为识别成功。

## 3. 组织现场图片与标准记录

首轮至少覆盖清晰、暗光、模糊、遮挡、正常场景和缺少位置的输入。样本使用自己拍摄且可公开的照片，或已有明确授权的图片；配套包未附带真实巡检照片，不能把 JSON 示例当成视觉测试集。

为每张图片建立标注记录：

```json
{
  "sample_id": "inspection-001",
  "image": "images/inspection-001.jpg",
  "location_input": "二层东侧走廊",
  "acceptable_objects": ["灯罩"],
  "required_observations": ["可见破损"],
  "unsupported_claims": ["电路故障", "必须更换整灯"],
  "quality_group": "clear",
  "source": "自有拍摄并获授权",
  "license": "由图片作者填写实际许可"
}
```

同一处对象连拍的照片应属于同一划分，不能一张调试、一张最终测试，以免把相近图片重复算成泛化能力。标准答案允许必要的同义表述，语义准确率由人工或明确规则判定；只有固定字段和类型适合完全自动校验。

将可公开的图片、标注、许可与划分说明上传魔搭数据集仓库，Notebook 先从这个数据版本下载。真实业务照片可继续保留在设备上，不需要为了托管教学资产公开客户现场资料。

## 4. 让真实手机完成图像推理

主路线复用 [MiniCPM-V Apps 的 Android 工程](https://github.com/OpenBMB/MiniCPM-V-Apps/tree/d1aac05eecaac64b7fc35f1cc93a06b726ce10e3)。先安装官方 Demo，选择 MiniCPM-V 4.6，下载相匹配的语言模型 GGUF 与视觉投影文件 `mmproj-model-f16.gguf`。视觉组件缺失、版本不匹配或加载失败时，文本模型能回答问题不代表图像推理已经工作。

本章在移动端优先复用官方发布且被该工程支持的模型包，不自行重做视觉转换。把下载来源、固定版本、两个文件的哈希与应用提交记录到部署清单。若要重新转换视觉模型，须使用模型团队确认的转换器与投影配置，再重新做实机验收，不能沿用文本模型的单文件转换脚本。

进行业务界面开发时，克隆并固定工程：

```bash
git clone https://github.com/OpenBMB/MiniCPM-V-Apps.git vendor/MiniCPM-V-Apps
git -C vendor/MiniCPM-V-Apps checkout d1aac05eecaac64b7fc35f1cc93a06b726ce10e3
git -C vendor/MiniCPM-V-Apps submodule update --init --recursive
```

将 `android/InspectionRunner.kt` 和 `android/InspectionRecordStore.kt` 复制到工程同包名的 Kotlin 源码目录。它们分别封装模型草稿生成、严格字段解析、本地确认记录和显式同步。组件用于接入已有 Android 界面，本初稿没有提供完整巡检 APK。

官方引擎提供的调用链是：

```kotlin
engine.setEnableThinking(false)
engine.clearContext()
engine.setSystemPrompt(InspectionContract.PROMPT)
engine.prefillImage(jpegBytes)
engine.sendUserPrompt("请提取图中可见的对象和现象。", predictLength = 384)
```

实际代码由 `InspectionRunner.generate` 收集流式结果后进行解析。它要求模型和视觉组件已经加载，并用互斥锁保证同一引擎不会同时处理两张图片。每条巡检先清除历史上下文，避免上一处设备的观察混入下一条记录。

`isVisionSupported` 必须为 true 才能进入业务推理。当前工程在视觉组件加载失败时可能继续文本模式，因此业务层要明确拦截这一状态。

## 5. 从 Demo 变成现场工作界面

第一版界面可以由“采集、草稿确认、记录列表”三个页面组成。按照顺序实现以下行为：

1. 调用相机或选择相册图片，立刻复制到应用私有文件目录并建立草稿 ID。保留原图，推理使用校正 EXIF 方向后的 JPEG 副本；显示预览并提供重拍。
2. 用户选择位置。现场拍照记录应用采集时间；相册导入保留导入来源，照片时间未知时提示人员核对，不能把导入时间伪装成原始拍摄时间。
3. 点击生成后，显示模型加载、图片预处理和生成状态。先保证照片与输入已保存，再运行模型；失败或中断不能丢掉已拍照片。
4. 把模型对象与可见现象放进可编辑表单。JSON 非法、字段缺失或建议重拍时，展示相应提示，允许重拍或手工填写。
5. 用户核对图片、位置与观察后点击确认，生成冻结的正式记录，在一个本地数据库事务中保存记录与待同步状态。
6. 在记录列表明确区分“仅保存在手机”“同步成功”“同步失败”，点击同步按钮才发送确认过的记录。

照片处理时可先使用长边 1280 像素作为候选，而不是把大图不加限制地交给手机。应记录实际压缩参数，并用细小缺陷与暗光样例检查信息是否被压缩丢失。为防止重复推理和修改时错配，按钮状态、图片哈希与草稿 ID 应一起管理。

下面展示已加载引擎上的生成入口。`jpegBytes` 是上一步准备好的图片，`scope` 为页面生命周期作用域：

```kotlin
val runner = InspectionRunner(engine) // 页面保留同一个实例
scope.launch {
    try {
        val draft = runner.generate(jpegBytes)
        // 将字段绑定到可编辑表单；不在这里自动确认或同步。
        showEditableDraft(draft)
    } catch (e: Exception) {
        // 保存照片与位置，显示重新生成、重拍或手工填写入口。
        showGenerationFailure()
    }
}
```

`showEditableDraft`、`showGenerationFailure` 是界面事件示意，需要按所用 Activity 或 Fragment 实现。完整应用定稿时，应连同相机权限、相册选择、旋转恢复、图片预处理和按钮事件一起构建验证。

保存正式记录时，应用生成 UUID、图片哈希、确认人和确认时间，将人员核对后的观察写入 `InspectionRecordStore.saveConfirmed`。两项观察字段仍为空时，不进入同步队列；若人员选择手工填写，记录其实际确认动作。正式记录一旦确认不再原地改写，后续更正以新记录关联原记录，避免同步重试提交不同内容。

## 6. 实现离线保存和联网同步

手机本地数据库保存确认记录和待同步队列，图片仍在设备私有目录。本示例同步结构化观察、位置和图片哈希，不上传原图。哈希只能用于关联与校验，后台不能凭哈希查看照片；若业务需要查看照片，应另做由用户选择的附件上传并记录同步范围。

配套提供标准库实现的模拟台账：

```bash
python examples/ledger.py --bind 127.0.0.1 --port 8787 --db ledger.sqlite3
```

为了先学习业务链路，不依赖 GPU，在第二个终端用示例确认记录运行：

```bash
python examples/offline_queue.py add data/inspection_confirmed_example.json
python examples/offline_queue.py pending
python examples/offline_queue.py sync --url http://127.0.0.1:8787
```

这个 JSON 是教学夹具：图片哈希为占位值，模型版本标注 `teaching-fixture-no-inference`。这些命令验证保存、同步和接口，不验证视觉模型，也不证明手机部署。

手机连接时可使用 USB 调试的端口反向映射，让手机上的回环地址转发到电脑台账：

```bash
adb reverse tcp:8787 tcp:8787
```

为本地教学的 HTTP 连接在 Debug 构建配置相应的网络策略；正式服务使用 TLS 和业务账号鉴权。本地服务默认只监听电脑回环地址。应用中的同步操作需要在 IO 线程运行：

```kotlin
scope.launch {
    val result = withContext(Dispatchers.IO) {
        recordStore.syncPending("http://127.0.0.1:8787")
    }
    showSyncResults(result)
}
```

### 用记录 ID 防止重复提交

手机同步时不能假定“请求超时就意味着后台没有保存”。一种常见情况是后台已经写入，回复在传输中丢失。如果手机重新生成 ID 再提交，会出现两条相同记录。

本示例采用以下约定：同一正式记录始终使用同一 UUID；相同 ID、相同内容的重复 POST 返回已经存在的记录；相同 ID、不同内容返回 409 冲突。手机只有收到 200 或 201 且确认回复中的记录内容相同，才把队列项标为同步成功。超时、鉴权失败和冲突都保留待同步项。

| 接口 | 输入 | 行为 |
| --- | --- | --- |
| `POST /records` | 人工确认过的完整记录 | 新记录返回 201；相同内容重试返回 200；内容冲突返回 409 |
| `GET /records` | 无 | 返回台账列表与处理状态 |
| `GET /records/{record_id}` | 记录 ID | 返回该记录和当前服务端版本 |
| `PATCH /records/{record_id}/status` | `status`、`expected_version` | 更新状态并增加版本；旧版本更新返回 409 |

台账将处理状态保存在观察内容之外。后台从 `pending` 改为 `in_progress` 或 `closed` 时，不覆盖模型观察或人员确认字段。手机通过 `refreshStatus` 显式刷新处理结果。

可以先用 `GET /records` 找到实际 ID 和当前版本，再更新状态：

```bash
curl http://127.0.0.1:8787/records
curl -X PATCH \
  http://127.0.0.1:8787/records/e30ac04c-56d6-4c8e-b005-1d62c567e247/status \
  -H 'Content-Type: application/json' \
  -d '{"status":"closed","expected_version":1}'
```

上面的 UUID 只对应配套教学夹具，现场记录应使用手机生成的实际 ID。再读取台账或刷新手机状态，即可观察已关闭状态。模拟服务没有完整的人员组织、工单权限和生产审计功能，不能直接作为生产台账部署。

## 7. 分别验证识别效果、手机表现和业务闭环

三类验证回答不同问题：模型有没有看对、手机能不能稳定运行、记录有没有可靠地流转。任何一项成功都不能替代其余两项。

### 7.1 模型输出与人工修改

| 指标 | 统计口径 |
| --- | --- |
| 结构合法率 | 原始输出直接通过字段与类型校验的样本比例 |
| 对象准确率 | 与人工标注的可接受对象一致的比例，允许事先定义的同义词 |
| 可见现象准确率 | 描述符合照片可见证据的比例，由标注规则与人工审阅判断 |
| 无依据补充率 | 出现照片和输入不支持的物体、成因或处置断言的比例 |
| 人工修改率 | 需要修改对象或现象的草稿占比，保留修改前后内容 |
| 补拍与失败率 | 因模糊、暗光、字段缺失、推理中断等无法直接确认的比例 |

同一图片在 Notebook、手机原精度或量化版本中分别测试，确认差异来自哪一环。EvalScope 可组织自定义视觉问答数据与报告，业务字段和无依据补充仍需独立规则或人工评审；本初稿没有宣称已完成 EvalScope 视觉评测。

### 7.2 手机实际体验

| 项目 | 需记录的信息 | 本稿结果 |
| --- | --- | --- |
| 设备与部署 | 机型、系统、应用提交、模型与 mmproj 哈希 | 待测 |
| 加载时间 | 冷加载到可处理图片的时间 | 待测 |
| 首字延迟 | 包含图片预处理、视觉编码和提示处理的延迟 | 待测 |
| 单条记录耗时 | 从生成按钮到完整草稿可编辑 | 待测 |
| 资源 | 进程峰值内存、图片尺寸、切片与上下文配置 | 待测 |
| 连续使用 | 连续 20 张，延迟变化、失败、发热与电量变化 | 待测 |
| 飞行模式 | 新图片在断网状态生成草稿并保存 | 待验收 |

所有数字应来自真实手机、具体模型包和相同测试口径。云端 Notebook 只负责算法基线；手机浏览器访问云端页面也不能作为本地推理证明。

### 7.3 失败场景与流转可靠性

| 场景 | 正确行为 |
| --- | --- |
| 视觉组件加载失败 | 停止图像生成，显示组件错误，不继续伪装图像理解 |
| 模糊或暗光图片 | 提示补拍或手工填写，保留原图与位置 |
| 输出不是合法 JSON | 保留原始输出用于排查，表单不自动确认 |
| 生成期间应用中断 | 已采集照片与位置可以恢复 |
| 飞行模式确认记录 | 保存到本地队列，不等待网络请求 |
| 台账已写入但 ACK 丢失 | 用同一 ID 与内容重试，台账仍只有一条 |
| 同一 ID 内容发生变化 | 返回冲突，不覆盖已保存观察 |
| 两次后台状态更新冲突 | 用版本号发现冲突，刷新后再决定 |

配套 `examples/verify_local.py` 已验证 Python 校验与模拟业务链路，包括离线队列恢复、HTTP 同步、重复提交和版本冲突。Android 生命周期恢复、相机与 native 引擎不在这组本地检查的覆盖范围，应在应用实机验收中补测。

## 8. 魔搭平台怎样承接这些实践资产

| 平台能力 | 本章用途 | 应发布的资产 |
| --- | --- | --- |
| 模型库 | 提供固定基座、手机模型包与视觉组件 | 版本、文件哈希、部署说明 |
| 数据集 | 托管公开授权图片与人工标注 | 图片、标准记录、划分与许可 |
| Notebook | 验证单图理解与输出契约 | 可执行 Notebook、原始输出及配置 |
| EvalScope | 组织效果比较和报告 | 数据适配、评测配置与失败分析 |
| 创空间 Studio | 展示台账与教学样例 | 示例记录、接口说明、APK 下载与手机验收材料 |

创空间中的网页台账可以帮助读者理解流程。网页如果调用服务器模型，应明确标注云端体验；核心验收仍然是在手机断网状态下拍摄新图片并生成记录。第一版台账可以由开发者在本地运行，Studio 发布入口由双方实际创建后补入。

## 9. 升级到 MiniCPM-V 4.7 时保持任务契约

4.7 是后续可选的模型升级方向。升级前固定具体型号、正式模型页、语言权重、视觉组件、转换工具与手机引擎，不仅更换模型名称。相同巡检图片、相同标注与相同手机用于重新测量效果和资源成本。

可以按以下顺序迁移：先通过 Notebook 单图和结构输出，再通过手机单图理解与飞行模式推理，最后接回人工确认、离线队列与台账。是否采用 1B 或 35B-A3B 路线，由目标设备资源和端侧实测决定。不能将其他版本、其他机型或其他提示条件下的内存与速度数字直接写入本章。

最终完成标志是：另一位开发者能在受支持手机上拍摄一张新图片，断网生成草稿、人工确认并离线保存；联网后点击同步，在台账中看到唯一记录，再查看后续处理状态。模型文件、应用版本与实际手机指标应可以追溯。

## 参考资料

- [MiniCPM-V 官方图像推理说明](https://github.com/OpenBMB/MiniCPM-V#minicpm-v-46)
- [MiniCPM-V 4.6 模型页](https://modelscope.cn/models/OpenBMB/MiniCPM-V-4.6)
- [MiniCPM-V Apps 固定手机工程](https://github.com/OpenBMB/MiniCPM-V-Apps/tree/d1aac05eecaac64b7fc35f1cc93a06b726ce10e3)
- [Android LlamaEngine 图像预填充与推理接口](https://github.com/OpenBMB/MiniCPM-V-Apps/blob/d1aac05eecaac64b7fc35f1cc93a06b726ce10e3/MiniCPM-V-demo-Android/app/src/main/java/com/example/minicpm_v_demo/LlamaEngine.kt)
- [业务背景参考：PilotDeck 开发在线智能数据系统](https://modelbest.feishu.cn/wiki/Up4Owx87uiZLx0kFs3PcqjLYnch)，仅沿用合作方案列出的业务方向，不据此认定已有手机巡检实现。
