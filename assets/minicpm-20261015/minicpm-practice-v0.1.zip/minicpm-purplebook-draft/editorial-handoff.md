# MiniCPM 共建章节定稿与入库说明

本包提供可供双方审阅的正文初稿与配套实现起点。正式发布前应补齐真实执行结果，使读者能够从下载资产到自己的手机完成整个流程。

## 与合作方案的对应

| Proposal 要求 | 初稿落实 | 定稿前补充 |
| --- | --- | --- |
| 小模型训练拆解 | 结构、训练阶段、数据与手机资源关系 | 模型团队审校公开训练口径 |
| 魔搭 Notebook 微调 | 专用模板、固定 ms-swift、LoRA Notebook | 在实际 Notebook 镜像执行并记录显存、时长和日志 |
| 数据与独立测试 | 320/64/96 条原创合成数据及模板分离 | 创建魔搭数据集；补充授权真实测试集 |
| 微调前后与量化评测 | 严格业务指标与原始失败输出 | 基座、合并、F16/Q4/Q8 实际报告 |
| 模型上传与可追溯发布 | 上传脚本、模型卡与产物关系 | 真实仓库链接、固定提交、模型与数据许可确认 |
| 手机部署 | 官方 Apps 固定工程，自定义文本模型注册与系统提示接入 | 构建APK；指定至少一台支持机型并验证自定义产物 |
| 手机业务流程 | 巡检字段、图像推理与本地记录组件 | 接入相机、表单、记录列表、恢复与同步按钮 |
| 台账闭环 | 标准库模拟服务、冻结记录、幂等提交与状态版本 | 手机显式同步、后台状态更新及手机刷新实测 |
| 创空间展示 | 区分手机推理与台账/网页演示 | 实际 Studio URL、下载说明与演示材料 |

合成测试采用不同外围模板与去重输入，但词汇与生成规则共享，不能称为真实业务泛化验证。模型能力指标与手机性能表尚未填入结果。

## 建议分工和发布顺序

| 工作 | 建议负责方 | 通过条件 |
| --- | --- | --- |
| 模型版本、训练路线与手机推理引擎 | 面壁模型/端侧工程团队 | 实际版本可下载，权重与分词器、视觉组件和运行时匹配 |
| 正文、样本标注与开发者复现材料 | OpenBMB 社区内容负责人 | 一位非原作者按教程完成指定流程 |
| Notebook镜像、模型数据仓库与Studio | 魔搭平台协作方 | 账号权限与入口实际可用、资产能下载与运行 |
| 模型效果和手机评测审阅 | 双方工程/评测人员 | 同数据、同提示、同设备的对照报告可追溯 |
| 章节编号与入库 | 魔搭紫皮书编辑维护者 | 目录、源HTML、生成Markdown与站点数据同步 |

先锁定模型和手机路线，在实际设备跑通单图与文本自定义模型；随后执行 Notebook 和量化评测；再补齐完整界面、台账与展示入口；最后由另一位开发者复现并审稿。这些是责任建议，不代表双方已经指定了具体人选。

## 紫皮书仓库接入

核对版本：`modelscope/ms-cookbook`，提交 `02f76c81df2e07da1c7dc389d840fd2b3b1bae4a`。当前 Part 3 已有 07—11 章，Part 5 已有 16—20 章；Part 7 的第 33 章是 Penguin Harness 产线巡检。新增手机章节强调现场采集和端侧推理，不重复其服务器模型与工具控制流程。

仓库明确规定 `content/source-html/*.html` 是正文源，`content/chapters/*.md` 为生成结果。审稿材料可以使用本包 Markdown；正式入库应导入 `source-html/` 候选源及自有流程图，由编辑决定编号，更新 `content/manifest.json`，再运行：

```bash
python3 scripts/build-content.py
node scripts/build-content.mjs --check
node scripts/check-site.mjs
```

本包不替换现有第 11、13、20 或 33 章，也不擅自改动整书编号。候选 HTML 中的图片相对路径需随正式章节位置调整；Notebook、代码和数据可放入维护者约定的实践资产目录并补链接。正式 PR 前重新读取当前仓库规范，检查目录可能发生的更新。

## 来源与版本核对

| 来源 | 核对内容 | 固定版本或范围 |
| --- | --- | --- |
| 用户上传的共建 Proposal | 两章目标、待办任务、手机现场巡检与魔搭能力 | 2026-10-11 附件 |
| [紫皮书 README 与贡献规范](https://github.com/modelscope/ms-cookbook) | 目录、读者、正文源和生成流程 | `02f76c81df2e07da1c7dc389d840fd2b3b1bae4a` |
| [MiniCPM](https://github.com/OpenBMB/MiniCPM) | 2B结构、阶段权重、训练路线、微调与转换入口 | `316cfb1cea39f39cfa16b4f5703b77495c2340be` |
| [ms-swift](https://github.com/modelscope/ms-swift) | 2B模板、非思考训练前缀、SFT标签与参数 | `654e24f17b5d9f40ed4b9ee4c56a723320244db5` |
| [MiniCPM-V](https://github.com/OpenBMB/MiniCPM-V) | 4.6 Transformers单图接口、压缩参数 | 2026-10-11 读取 README 对应章节；正式发布再固定提交 |
| [MiniCPM-V Apps](https://github.com/OpenBMB/MiniCPM-V-Apps) | 模型列表、下载器、系统提示、图像预填充与原生接口 | `d1aac05eecaac64b7fc35f1cc93a06b726ce10e3` |
| [ModelScope SDK](https://github.com/modelscope/modelscope/tree/v1.33.0) | upload_folder 参数；避免旧 push_model 方式 | `v1.33.0` |
| [EvalScope](https://github.com/modelscope/evalscope) | general_qa数据格式、默认指标与自定义评测边界 | `3af6b5f0412a4eb88bc2dcd4308b2e0fe6713de1` |
| [llama.cpp](https://github.com/ggml-org/llama.cpp) | 转换候选提交 | `23b0202a189c44a54625aadcb37a946dd1d6278d`，尚需端侧互操作验收 |

硬件资源建议、初始训练参数和物业业务设计是本次初稿的实现选择；官方公开入口不等于本次已经完成对应验证。PilotDeck 链接仅沿用 Proposal 的业务背景引用，未读取其全文，也未据此描述实现细节。
