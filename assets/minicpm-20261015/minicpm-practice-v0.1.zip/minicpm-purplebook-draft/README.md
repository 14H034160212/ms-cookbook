# OpenBMB 与魔搭紫皮书 MiniCPM 共建章节初稿

交付日期：2026-10-11。依据用户提供的共建 Proposal 与魔搭紫皮书当前仓库编写。两章围绕可实践的任务展开，章节编号待魔搭编辑统一安排。

## 阅读顺序

| 章节 | 主模型与任务 | 初稿内容 |
| --- | --- | --- |
| Part 3 把自己微调的 MiniCPM 装进手机 | MiniCPM5-2B，日常记录转固定格式待办 | 训练拆解、魔搭 Notebook、LoRA、前后评测、合并、GGUF、模型上传与自定义 Android 模型注册 |
| Part 5 用 MiniCPM-V 搭建手机巡检助手 | MiniCPM-V 4.6，物业现场观察记录 | 单图基线、字段责任、Android 图像推理组件、人工确认、离线保存与台账同步 |

模型版本按公开工程可核查程度选定。4.7 迁移路径见 Part 5 最后一节；它不改变业务任务契约，需重新固定模型、视觉组件与手机引擎并验收。

## 包含的文件

- `chapters/`：两章可审阅 Markdown。
- `source-html/`：适配紫皮书规范的 HTML 正文候选源；不含正式章节编号。
- `figures/`：训练与巡检流程 SVG。
- `notebooks/`：文本微调和视觉基线两份 Notebook，保留未执行状态。
- `data/`：320 条训练、64 条验证、96 条测试，及标准答案、数据哈希和 EvalScope 问答格式。
- `examples/`：数据生成、严格评测、Transformers 基线、GGUF 转换、模型上传、自定义手机模型注册及模拟台账。
- `android/`：图像推理、结构解析、本地记录与显式同步的 Kotlin 集成组件。
- `model-card-template.md`：模型发布填写模板。
- `editorial-handoff.md`：定稿所需补充资产、角色建议和入库说明。
- `validation.json`：本次验证范围与结果。

## 不需要 GPU 的本地检查

要求 Python 3.11+，在项目根目录执行：

```bash
python examples/build_data.py
python examples/verify_local.py
```

模拟业务流程：

```bash
python examples/ledger.py
```

另一个终端执行：

```bash
python examples/offline_queue.py add data/inspection_confirmed_example.json
python examples/offline_queue.py sync
```

示例确认记录是教学夹具，包含占位图片哈希，未进行真实图片推理。

## 验证状态

本次验证通过 6 项本地检查，覆盖划分去重与标签依据、非法 JSON 与字段计分、草稿契约、确认门槛、ACK 丢失后的幂等重试、状态版本冲突、离线队列恢复和实际 localhost HTTP 同步。两份 Notebook 的 JSON 结构及全部代码单元语法检查通过，全部 Python 脚本与 Shell 脚本通过语法检查。自定义 Android 注册脚本已对读取到的固定上游源码执行试验，确认两处系统提示入口和模型注册项生成。

尚未执行 GPU 训练、真实图片推理、GGUF 转换、魔搭模型上传、Android 编译与实机评测；没有附带训练权重、APK、手机性能数字或可公开的真实巡检图片。Kotlin 组件是待编译集成源，完整业务界面仍需实现。这些状态在章节中逐项说明。

## 内容与代码许可

`data/` 中通过本包生成的待办合成教学样本与生成规则可按 CC0-1.0 使用。其余本次新增教程、图示与示例代码提供为共建审稿材料，正式公开时由作者与魔搭确认最终许可；引用的模型、代码工程与数据遵循各自许可，不因本包而改变。无需分发上游完整源码即可使用本包的接入脚本。
